from clean_folder import clean

__all__ = ['clean']
